
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Plane } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 px-6 py-10 space-y-12">
      {/* Hero Section */}
      <section className="text-center space-y-4">
        <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-4xl font-bold">
          Your Reliable Partner in the Skies
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-lg max-w-2xl mx-auto">
          We specialize in charter flight operations, connecting destinations with precision, reliability and comfort.
        </motion.p>
      </section>

      {/* Routes Section */}
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-center">Our Charter Routes</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[
            { from: "Istanbul (IST)", to: "Jeddah (JED)" },
            { from: "Izmir (ADB)", to: "Naples (NAP)" },
            { from: "Antalya (AYT)", to: "Sharm El-Sheikh (SSH)" },
            { from: "Ankara (ESB)", to: "Casablanca (CMN)" },
            { from: "Bodrum (BJV)", to: "Bergamo (BGY)" },
          ].map((route, idx) => (
            <Card key={idx} className="rounded-2xl shadow p-4">
              <CardContent className="flex items-center gap-4">
                <Plane className="w-6 h-6" />
                <div>
                  <div className="font-medium">{route.from} → {route.to}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Airlines Section */}
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-center">Airlines We Work With</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-8">
          {[
            {
              name: "Corendon Airlines",
              logo: "/logos/corendon.png",
              fleet: "Boeing 737-800, Boeing 737 MAX 8",
              image: "/aircrafts/corendon-737.jpg"
            },
            {
              name: "Tailwind Airlines",
              logo: "/logos/tailwind.png",
              fleet: "Boeing 737-400",
              image: "/aircrafts/tailwind-737.jpg"
            },
            {
              name: "Freebird Airlines",
              logo: "/logos/freebird.png",
              fleet: "Airbus A320",
              image: "/aircrafts/freebird-a320.jpg"
            },
            {
              name: "Pegasus Airlines",
              logo: "/logos/pegasus.png",
              fleet: "Airbus A320neo, Boeing 737-800",
              image: "/aircrafts/pegasus-a320neo.jpg"
            },
          ].map((airline, idx) => (
            <Card key={idx} className="rounded-2xl overflow-hidden shadow">
              <img src={airline.image} alt={airline.name} className="w-full h-40 object-cover" />
              <CardContent className="flex flex-col items-center text-center space-y-2 p-4">
                <img src={airline.logo} alt={airline.name} className="h-10 object-contain" />
                <div className="font-medium text-lg">{airline.name}</div>
                <div className="text-sm text-gray-600">Fleet: {airline.fleet}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">Who We Are</h2>
        <p className="max-w-2xl mx-auto text-gray-700">
          With years of experience in aviation, we provide tailored charter flight solutions to tour operators across the globe. Our commitment to safety, punctuality, and customer satisfaction is what makes us a trusted partner.
        </p>
      </section>

      {/* Contact Section */}
      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">Get in Touch</h2>
        <p className="text-gray-700">Have a question or want to collaborate? Contact us via email.</p>
        <div className="flex justify-center">
          <Button className="flex items-center gap-2">
            <Mail className="w-4 h-4" /> contact@yourchartersite.com
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center text-sm text-gray-500 pt-10">
        &copy; {new Date().getFullYear()} Your Charter Company. All rights reserved.
      </footer>
    </main>
  );
}
